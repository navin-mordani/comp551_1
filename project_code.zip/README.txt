
To produce prediction file:
  - Run the main.py file.
  - Wait
  - Its long...
  - Output is predictions.csv

To reproduce features used in Y1 from original data:
  - Run data/stackData.py
  - Run data/Y1/meltDataY1.py
